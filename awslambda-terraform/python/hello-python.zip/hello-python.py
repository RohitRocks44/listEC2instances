import boto3
from PIL import Image
import io

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    image = s3.get_object(Bucket=bucket, Key=key)['Body']
    img = Image.open(image)
    img = img.resize((100, 100))
    
    out_img = io.BytesIO()
    img.save(out_img, 'JPEG')
    out_img.seek(0)
    
    s3.put_object(Bucket=bucket, Key='resized-'+key, Body=out_img, ContentType='image/jpeg')
    return {'statusCode': 200, 'body': 'Image resized and saved.'}

